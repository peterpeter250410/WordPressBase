<?php get_header(); ?>

<main class="site-content">
    <h1>404 - Page Not Found</h1>
    <p>The page you are looking for does not exist.</p>
    <p><a href="<?php echo esc_url(home_url('/')); ?>">Back to homepage</a></p>
</main>

<?php get_footer(); ?>
